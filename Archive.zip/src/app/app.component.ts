import { EnrollmentService } from './enrollment.service';
import { Component } from '@angular/core';
import { User  } from './user';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'tdf';
  topicHasError = true;
  options=['Angular','Node','Flutter']
  user = new User('Ayan','ayan.test@gmail.com',9132300112,'Angular','morning',true);
  submitted = false;
  constructor(private _enrollmentservice:EnrollmentService){}
  errorMsg:string | undefined;

  validateTopic(value:any){
    value=="default"?this.topicHasError = true: this.topicHasError = false;
  }

  onSubmit(userForm:any){
    // console.log(userForm)
    this.submitted = true;
    this._enrollmentservice.enroll(this.user)
    .subscribe(
      data=>{console.log('success',data)},
      error=>{this.errorMsg=error.statusText}
    )
    console.log(this.user)
  }
}
